import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;

public class GoBoomGUI extends Application {
    private static final int NUM_CARDS_PER_PLAYER = 7;
    private Player[] players;
    private List<Card> deck;
    private Map<Player, Card> trick;
    private Player currentPlayer;
    private Card currentCard;

    private Label currentPlayerLabel;
    private Label trickLabel;
    private Label handLabel;
    private ComboBox<Rank> rankComboBox;
    private ComboBox<Suit> suitComboBox;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("GoBoom Game");

        // Initialize game components
        initializeGame();

        // Create GUI components
        currentPlayerLabel = new Label("Current Player: " + currentPlayer.getName());
        trickLabel = new Label();
        handLabel = new Label();

        rankComboBox = new ComboBox<>();
        rankComboBox.setPromptText("Select Rank");
        rankComboBox.getItems().addAll(Rank.values());

        suitComboBox = new ComboBox<>();
        suitComboBox.setPromptText("Select Suit");
        suitComboBox.getItems().addAll(Suit.values());

        Button playButton = new Button("Play");
        playButton.setOnAction(e -> playCard());

        Button drawButton = new Button("Draw");
        drawButton.setOnAction(e -> drawCard());

        // Create the layout
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(currentPlayerLabel, trickLabel, handLabel,
                rankComboBox, suitComboBox, playButton, drawButton);

        // Update initial labels
        updateTrickLabel();
        updateHandLabel();

        // Set the scene
        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initializeGame() {
        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");
        Player player3 = new Player("Player 3");
        Player player4 = new Player("Player 4");

        players = new Player[]{player1, player2, player3, player4};

        deck = new ArrayList<>();
        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                deck.add(new Card(rank, suit));
            }
        }

        Collections.shuffle(deck);

        // Display the lead card
        Card leadCard = deck.remove(deck.size() - 1);
        System.out.println("Lead card: " + leadCard);

        currentPlayer = findPlayerWithLeadCard(leadCard);
        System.out.println("Starting with player: " + currentPlayer);

        for (int i = 0; i < NUM_CARDS_PER_PLAYER; i++) {
            for (Player player : players) {
                Card card = deck.remove(deck.size() - 1);
                player.drawCard(card);
            }
        }

        trick = new HashMap<>();
    }

    private Player findPlayerWithLeadCard(Card leadCard) {
        for (Player player : players) {
            if (player.hasCard(leadCard)) {
                return player;
            }
        }
        return null;
    }

    private void updateTrickLabel() {
        StringBuilder trickText = new StringBuilder("Current Trick: ");
        for (Map.Entry<Player, Card> entry : trick.entrySet()) {
            Player player = entry.getKey();
            Card card = entry.getValue();
            trickText.append(player.getName()).append(": ").append(card.toString()).append(" | ");
        }
        trickLabel.setText(trickText.toString());
    }

    private void updateHandLabel() {
        StringBuilder handText = new StringBuilder("Your Hand: ");
        List<Card> hand = currentPlayer.getHand();
        for (Card card : hand) {
            handText.append(card.toString()).append(" | ");
        }
        handLabel.setText(handText.toString());
    }

    private void playCard() {
        Rank selectedRank = rankComboBox.getValue();
        Suit selectedSuit = suitComboBox.getValue();

        if (selectedRank == null || selectedSuit == null) {
            showAlert("Invalid Move", "Please select a valid rank and suit.");
            return;
        }

        Card move = new Card(selectedRank, selectedSuit);
        if (!currentPlayer.isValidMove(currentCard, move)) {
            showAlert("Invalid Move", "You cannot play that card. Please choose a valid move.");
            return;
        }

        if (!currentPlayer.removeCard(move)) {
            showAlert("Invalid Move", "You don't have that card in your hand. Please choose a valid move.");
            return;
        }

        trick.put(currentPlayer, move);
        currentCard = move;
        updateTrickLabel();
        updateHandLabel();

        Player winner = null;
        if (trick.size() == players.length) {
            winner = getWinner(trick);
            System.out.println("Winner of the trick: " + winner);
            trick.clear();
            currentPlayer = winner;
            updateTrickLabel();
        } else {
            currentPlayer = getNextPlayer();
        }

        currentPlayerLabel.setText("Current Player: " + currentPlayer.getName());

        if (winner != null && winner.getHand().isEmpty()) {
            showAlert("Game Over", "The game is over. The winner is: " + winner.getName());
        }
    }

    private Player getNextPlayer() {
        int currentPlayerIndex = Arrays.asList(players).indexOf(currentPlayer);
        int nextPlayerIndex = (currentPlayerIndex + 1) % players.length;
        return players[nextPlayerIndex];
    }

    private Player getWinner(Map<Player, Card> trick) {
        Player winner = null;
        Card highestCard = null;
        for (Map.Entry<Player, Card> entry : trick.entrySet()) {
            Card card = entry.getValue();
            if (highestCard == null || card.getRank().ordinal() > highestCard.getRank().ordinal()) {
                highestCard = card;
                winner = entry.getKey();
            }
        }
        return winner;
    }

    private void drawCard() {
        if (deck.isEmpty()) {
            showAlert("No Cards Left", "The deck is empty. Skipping to the next player.");
            currentPlayer = getNextPlayer();
            currentPlayerLabel.setText("Current Player: " + currentPlayer.getName());
            return;
        }

        Card drawnCard = deck.remove(deck.size() - 1);
        currentPlayer.drawCard(drawnCard);
        updateHandLabel();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }

    enum Rank {
        TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE
    }

    enum Suit {
        CLUBS, DIAMONDS, HEARTS, SPADES
    }

    static class Card {
        private Rank rank;
        private Suit suit;

        public Card(Rank rank, Suit suit) {
            this.rank = rank;
            this.suit = suit;
        }

        public Rank getRank() {
            return rank;
        }

        public Suit getSuit() {
            return suit;
        }

        @Override
        public String toString() {
            return rank + " of " + suit;
        }
    }

    static class Player {
        private String name;
        private List<Card> hand;

        public Player(String name) {
            this.name = name;
            this.hand = new ArrayList<>();
        }

        public String getName() {
            return name;
        }

        public List<Card> getHand() {
            return hand;
        }

        public void drawCard(Card card) {
            hand.add(card);
        }

        public boolean removeCard(Card card) {
            return hand.removeIf(c -> c.getRank() == card.getRank() && c.getSuit() == card.getSuit());
        }

        public boolean hasCard(Card card) {
            return hand.contains(card);
        }

        public boolean isValidMove(Card currentCard, Card move) {
            if (move.getSuit() == currentCard.getSuit()) {
                return true;
            } else {
                for (Card card : hand) {
                    if (card.getSuit() == currentCard.getSuit()) {
                        return false;
                    }
                }
                return true;
            }
        }

        @Override
        public String toString() {
            return name;
        }
    }

}

